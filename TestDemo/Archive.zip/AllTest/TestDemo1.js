import React from 'react';

import {
    View, 
    Text,
    SafeAreaView,
    TextInput,
    StyleSheet,
    Image
} from 'react-native';
import FetchData from './FetchData';


export default function TestDemo() {
    return(
        <SafeAreaView>
            
          
                <FetchData />
        
        </SafeAreaView>
    );
}

styles= StyleSheet.create({
   
})