import React, { Component } from 'react';
import { 
    View, 
    Text,
    FlatList, 
    ActivityIndicator,
    StyleSheet,
    SafeAreaView,
    Image,
    TouchableOpacity,
    TextInput
} from 'react-native';
import axios from 'axios';

export default class FetchData extends Component {
  constructor(props) {
    super(props);
    this.state = {
        userData: [],
        isLoader: true,
        show: -1,
        search: 'noida'
    };
  }

componentDidMount(){
  this.handleUrl();
}

toggle=(key)=>{
// console.warn('key', key)
    this.setState({
        show: this.state.show === key ? -1 : key,
    })
}

handleUrl(){
    // console.warn(this.state.search);
    return fetch('https://newsapi.org/v2/everything?q='+this.state.search+'&apiKey=6e44b6acc6564f6eb35e3ac41763447f')
    .then(response => response.json())
    .then((responseJson) =>{
        // console.warn(responseJson)
        this.setState({
            userData: responseJson.articles,
            isLoader: false,
        })
//    console.warn(this.state.userData)

    }).catch(err=> {
        console.warn('err', err)
    })
    
}
  render() {
    return (
        
      <View>
          <View>
                <TextInput placeholder='Enter City' style={styles.search} value={this.state.search} onChangeText={(text) => this.setState({search : text})} onSubmitEditing={this.handleUrl.bind(this)}/> 
                <Image source={require('./sera2.png')} style={styles.searchImg}/>
            </View>
          <ActivityIndicator size='large' animating={this.state.isLoader}/>
        <FlatList 
            data={this.state.userData}
            keyExtractor = {({id},index) => id}
            renderItem={({item,index})=> {
                return(
                    <View syle={{flexDirection: 'row'}}>
                    <View style={styles.flat}> 
                        <View style={styles.card}>
                            <View style={{paddingTop: 10}}>
                                <Text style={styles.mytext}>Title: {item.title}{`\n`}</Text> 
                                <Text style={styles.mytext} numberOfLines={this.state.show === index ? null : 2}>Description: {item.content == null ? item.description : item.content}</Text>
                                <TouchableOpacity  onPress={() => this.toggle(index)}>
                                    <Image source={this.state.show === index ? require('./remove.png') : require('./add.png')} style={{height: 30, width: 30,marginTop: 5,}}/>
                                </TouchableOpacity>
                            </View> 
                       </View>
                    </View>
                        <View style={styles.imgView}>
                            <Image style={styles.img}
                            source={{ uri: item.urlToImage ? item.urlToImage : 'https://upload.wikimedia.org/wikipedia/commons/a/ac/No_image_available.svg' }} />
                        </View>   
                    </View>
                )      
            }}
        />
      </View>
    );
  }
}

styles=StyleSheet.create({
    flat: {
        margin: 20,
        marginTop: 0,
        flexDirection: 'row'
    },
    card: {
        backgroundColor: '#dcdfe3',
        borderWidth: 2,
        borderRadius: 10,
        padding: 20,
        shadowColor: '#bec1c4',
        shadowOpacity: 3,
        shadowRadius: 10,
        elevation: 10,
        shadowOffset: {height: 15, width: 15},
        marginTop: 30
    },
    mytext: {
        fontWeight: 'bold'
    },
    imgView: {
        height: 60,
        width: 60,
        borderRadius: 10,
        position: 'absolute',
        marginLeft: 40,
        borderWidth: 2
    },
    img: {
        height:'100%',
        width:'100%',
        borderRadius: 10,
    },
    search: {
        borderWidth: 1,
        height: 50,
        borderRadius: 25,
        alignItems: 'center',
        paddingLeft: 50,
        paddingRight: 20,
        fontSize: 25,
        margin: 20
    },
    searchImg: {
        position: 'absolute',
        height: 30,
        width: 30,
        marginTop: 30,
        marginLeft: 30,
        
    },
})