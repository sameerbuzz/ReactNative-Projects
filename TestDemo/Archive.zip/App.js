import React, { Component } from 'react';
import { View } from 'react-native';
import TestDemo1 from './AllTest/TestDemo1';

export default class App extends Component {

  render() {
    return (
      <View>
        <TestDemo1 />
      </View>
    );
  }
}
