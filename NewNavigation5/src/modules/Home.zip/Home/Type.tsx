export const UPDATE_EMAIL = "SignIn/UPDATE_EMAIL";
export const UPDATE_PASSWORD = "SignIn/UPDATE_PASSWORD";
export const UPDATE_UID = "SignIn/UPDATEUID";
